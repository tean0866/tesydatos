# SMP's Revival
A 16x medieval fantasy resource pack for Minecraft. Originally created by SMP. Maintained by the staff of the Akenland server, and conmunity contributions.

This branch is the **Minecraft 1.12** version of the pack. [Download here, for the latest changes.](http://revival.akenland.com/downloads/revival-12.zip)

## External Links
* [Official Website](https://revival.akenland.com)
* [Original Minecraft Forum thread (by SMP)](http://www.minecraftforum.net/forums/mapping-and-modding/resource-packs/1228756-smps-revival-october-20th-2014-1-8-sans-ctm)
* [New Minecraft Forum thread](https://www.minecraftforum.net/forums/mapping-and-modding-java-edition/resource-packs/2822930-new-release-smps-revival-fan-continuation-1-12)
